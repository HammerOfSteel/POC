#!/bin/bash

# Check if python is installed
if ! command -v python3 &> /dev/null
then
    echo "Python could not be found. Installing Python..."
    sudo apt-get update
    sudo apt-get install -y python3
fi

# Check if pip is installed
if ! command -v pip3 &> /dev/null
then
    echo "pip could not be found. Installing pip..."
    sudo apt-get install -y python3-pip
fi

# Install packages from requirements.txt
echo "Installing requirements..."
pip3 install pandas
pip3 install psutil
pip3 install speedtest-cli
pip3 install requests
pip3 install psycopg2-binary
pip3 install fastapi
pip3 install starlette
pip3 install azure-storage-blob
pip3 install PyYAML
pip3 install scapy
pip3 install git+https://github.com/coolbho3k/manuf.git
pip3 install typing
pip3 install uvicorn
pip install python3-nmap
pip3 install sqlalchemy

echo "Running cyclopse manager..."
python3 ./init-manager.py &
