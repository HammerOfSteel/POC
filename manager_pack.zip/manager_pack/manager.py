import pandas as pd
import os
import sys
import csv
import zipfile
import platform
import subprocess
import socket
from datetime import datetime
import psutil
import shutil
import speedtest
import requests
import psycopg2
from psycopg2 import sql
from fastapi import FastAPI, Depends, HTTPException, UploadFile, File
from fastapi.responses import JSONResponse
from fastapi.security import APIKeyHeader
from starlette.status import HTTP_403_FORBIDDEN
from azure.storage.blob import BlobServiceClient
import yaml
import json
from scapy.all import ARP, Ether, srp
from manuf import manuf
from typing import Optional
import nmap3
from sqlalchemy import Column, String, Integer, BigInteger, Float, JSON, DateTime, types, create_engine, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker


Base = declarative_base()

class CustomerInfo(Base):
    __tablename__ = 'customer_info'

    ID = Column(UUID(as_uuid=True), primary_key=True)
    Customer_Name = Column(String(100))
    Customer_Phone = Column(String(20))
    Customer_Email = Column(String(100))

class Asset(Base):
    __tablename__ = 'asset'

    ID = Column(UUID(as_uuid=True), primary_key=True)
    Asset_name = Column(String(100))
    Asset_Vendor = Column(String(100))
    Asset_OS = Column(String(100))
    Asset_IP = Column(String(20))
    Asset_Installed_On = Column(String(20))
    Asset_Type = Column(String(100))
    Customer_Name = Column(String(100))

class SystemSpecs(Base):
    __tablename__ = 'system_specs'

    ID = Column(UUID(as_uuid=True), primary_key=True)
    System_OS = Column(String(100))
    System_Version = Column(String(100))
    System_Vendor = Column(String(100))
    System_Hostname = Column(String(100))
    System_IP = Column(String(20))
    System_Type = Column(String(100))
    System_Installed_On = Column(DateTime)
    System_Uptime = Column(String(100))
    System_Disks = Column(JSON)
    System_CPU_Total = Column(Integer)
    System_CPU_Usage = Column(Float)
    System_MEM_Total = Column(BigInteger)
    System_MEM_Usage = Column(Float)
    System_Speed_Upload = Column(Float)
    System_Speed_Download = Column(Float)
    Customer_Name = Column(String(100))

class Programs(Base):
    __tablename__ = 'programs'

    ID = Column(UUID(as_uuid=True), primary_key=True)
    Program_Name = Column(String(100))
    Program_Version = Column(String(100))
    Program_Type = Column(String(100))
    Program_Hostname = Column(String(100))
    Program_Size = Column(BigInteger)
    Program_Vendor = Column(String(100))
    Program_Install_On = Column(DateTime)
    Program_Package_Manager = Column(String(50))
    Customer_Name = Column(String(100))

class Processes(Base):
    __tablename__ = 'processes'

    ID = Column(UUID(as_uuid=True), primary_key=True)
    Process_Name = Column(String(100))
    Process_Type = Column(String(100))
    Process_Resource_Usage_CPU = Column(String(100))
    Process_Resource_Usage_MEM = Column(String(100))
    Process_Start_Time = Column(DateTime)
    Process_PID = Column(Integer)
    Process_Network_Communication_Ports = Column(String(200))
    Customer_Name = Column(String(100))

class Patches(Base):
    __tablename__ = 'patches'

    ID = Column(UUID(as_uuid=True), primary_key=True)
    Patch_Name_ID = Column(String(100))
    Patch_Date = Column(DateTime)
    Patch_Package_Manager = Column(String(50))
    Customer_Name = Column(String(100))

class Firewall(Base):
    __tablename__ = 'firewall'

    ID = Column(UUID(as_uuid=True), primary_key=True)
    Policy_Name = Column(String(100))
    Policy_Type = Column(String(100))
    Policy_Source = Column(String(100))
    Policy_Destination = Column(String(100))
    Policy_Protocol = Column(String(50))
    Policy_Ports = Column(String(100))
    Customer_Name = Column(String(100))

class NetworkDiscovery(Base):
    __tablename__ = 'network_discovery'

    ID = Column(UUID(as_uuid=True), primary_key=True)
    Networkdiscovery_customer_name = Column(String(100))
    Networkdiscovery_IP = Column(String(20))
    Networkdiscovery_Status = Column(String(50))
    Networkdiscovery_FQDN = Column(String(100))
    Networkdiscovery_MAC = Column(String(20))
    Networkdiscovery_Vendor = Column(String(100))
    Networkdiscovery_Hostname = Column(String(100))
    Networkdiscovery_Alias = Column(String(100))
    Customer_Name = Column(String(100))

class Audit(Base):
    __tablename__ = 'audit'

    ID = Column(UUID(as_uuid=True), primary_key=True)
    Severity_Level = Column(String(50))
    Type = Column(String(100))
    Name = Column(String(100))
    Version = Column(String(100))
    Info = Column(Text)
    Customer_Name = Column(String(100))



def read_db_config():
    with open("config.yml", 'r') as stream:
        try:
            config = yaml.safe_load(stream)
            db_config = config['database']
            return db_config
        except yaml.YAMLError as exc:
            print(exc)

def read_api_config():
    with open("config.yml", 'r') as stream:
        try:
            config = yaml.safe_load(stream)
            api_config = config['api']
            return api_config
        except yaml.YAMLError as exc:
            print(exc)

def read_customer_config():
    with open("config.yml", 'r') as stream:
        try:
            config = yaml.safe_load(stream)
            customer_config = config['customer']
            return customer_config
        except yaml.YAMLError as exc:
            print(exc)

db_config = read_db_config()
api_config = read_api_config()
customer_config = read_customer_config()

db_name = db_config['db_name']
db_user = db_config['db_user']
db_pass = db_config['db_pass']
db_host = db_config['db_host']
db_port = db_config['db_port']
DATABASE_URL = f"postgresql://{db_user}:{db_pass}@{db_host}:{db_port}/{db_name}"
engine = create_engine(DATABASE_URL)
Session = sessionmaker(autocommit=False, autoflush=False, bind=engine)

CUSTOMER = customer_config['name']
CUSTOMER_EMAIL = customer_config['email']
CUSTOMER_PHONE = customer_config['phone']


# Define API key and FastAPI app
API_KEY = api_config['key']
api_key_header = APIKeyHeader(name="api_key", auto_error=True)
app = FastAPI()

def Get_Customer_info():
    sys.stdout.write("Getting customer info...\n")
    sys.stdout.write("\n")
    customer_info = {}
    customer_info["Customer_Name"] = CUSTOMER
    customer_info["Customer_Email"] = CUSTOMER_EMAIL
    customer_info["Customer_Phone"] = CUSTOMER_PHONE
    sys.stdout.write("Got customer info\n")
    sys.stdout.write("\n")
    return customer_info

def nmap_discovery():
    network = socket.gethostbyname(socket.gethostname()) + "/24"
    nmap = nmap3.Nmap()
    results = nmap.scan_top_ports(network)

    assets = []
    for ip, info in results.items():
        asset = {
            "ip": ip,
            "hostname": info.get("hostname", ""),
            "details": info.get("ports", [])
        }
        assets.append(asset)
    
    return json.dumps(assets, indent=4)

def NetworkDiscovery():
    sys.stdout.write("Doing network discovery...\n")
    sys.stdout.write("\n")
    p = manuf.MacParser()
    alias = socket.gethostname()
    customerNameArr = []
    FirewallVendorArr = []
    HostDiscovery = []
    HostResourcesArr = []
    Networkdiscovery = pd.DataFrame()
    IPV4Arr = []
    StatusArr = []
    FQDNArr = []
    HostnameArr = []
    AliasArr = []
    MACArr = []
    VendorArr = []
    customerNameArr = []
    host_name = socket.gethostname()
    Host = socket.gethostbyname(host_name)
    target_ip = Host+"/24"
    from scapy.all import ARP, Ether, srp

    #target_ip = "192.168.1.1/24"
    # IP Address for the destination
    # create ARP packet
    arp = ARP(pdst=target_ip)
    # create the Ether broadcast packet
    # ff:ff:ff:ff:ff:ff MAC address indicates broadcasting
    ether = Ether(dst="ff:ff:ff:ff:ff:ff")
    # stack them
    packet = ether/arp

    result = srp(packet, timeout=3, verbose=0)[0]

    # a list of clients, we will fill this in the upcoming loop
    clients = []

    for sent, received in result:
        # for each response, append ip and mac address to `clients` list
        clients.append({'ip': received.psrc, 'mac': received.hwsrc})

    # print clients
    for client in clients:
        customerNameArr.append(CUSTOMER)
        AliasArr.append(host_name)
        HostnameArr.append(alias)
        StatusArr.append("Up")
        MACArr.append(client['mac'])
        IPV4Arr.append(client['ip'])
        try:
            sys.stdout.write("Mac: {}".format(client['mac']))
            vendor = p.get_manuf(client['mac'])
            sys.stdout.write("Vendor: {}".format(vendor))
        except Exception as e:
            sys.stdout.write("Error on getting vendor: {}".format(e))
            sys.stdout.write("Mac was: {}".format(client['mac']))
            vendor = "Default"
        VendorArr.append(vendor)
    
    Networkdiscovery['Networkdiscovery_customer_name'] = pd.Series(customerNameArr)
    Networkdiscovery['Networkdiscovery_IP'] = pd.Series(IPV4Arr)
    Networkdiscovery['Networkdiscovery_Status'] = pd.Series(StatusArr)
    Networkdiscovery['Networkdiscovery_FQDN'] = pd.Series(HostnameArr)
    Networkdiscovery['Networkdiscovery_MAC'] = pd.Series(MACArr)
    Networkdiscovery['Networkdiscovery_Vendor'] = pd.Series(VendorArr)
    Networkdiscovery['Networkdiscovery_Hostname'] = pd.Series(HostnameArr)
    Networkdiscovery['Networkdiscovery_Alias'] = pd.Series(HostnameArr)
    sys.stdout.write("Completed network discovery\n")
    sys.stdout.write("\n")
    return Networkdiscovery

def get_installed_programs_linux():
    sys.stdout.write("Getting installed programs...\n")
    sys.stdout.write("\n")
    try:
        installed_programs = []

        # Get the system hostname
        hostname = socket.gethostname()

        # Detect package manager
        package_manager = None
        for manager in ["apt", "yum", "dnf"]:
            if subprocess.run(["which", manager], stdout=subprocess.DEVNULL).returncode == 0:
                package_manager = manager
                break

        if package_manager == "apt":
            # Execute the dpkg-query command for Debian-based systems
            result = subprocess.run(
                ["dpkg-query", "-W", "-f=${binary:Package} ${Version} ${Architecture} ${Installed-Size} ${Maintainer}\n"],
                stdout=subprocess.PIPE,
                text=True,
                check=True
            )

            # Parse the output
            for line in result.stdout.strip().split("\n"):
                name, version, arch, size, vendor = line.strip().split(" ", 4)
                # Get the modification time of the .list file as the install date
                list_file = f"/var/lib/dpkg/info/{name}.list"
                install_date = ''
                if os.path.isfile(list_file):
                    timestamp = os.path.getmtime(list_file)
                    install_date = datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')
                installed_programs.append({
                    "Program_Name": name,
                    "Program_Version": version,
                    "Program_Type": arch,
                    "Program_Hostname": hostname,
                    "Program_Size": size,
                    "Program_Vendor": vendor,
                    "Program_Install_On": install_date,
                    "Program_Package_Manager": "apt"
                })

        elif package_manager in ["yum", "dnf"]:
            # Execute the rpm command for Red Hat-based systems
            result = subprocess.run(
                ["rpm", "-qa", "--queryformat", "%{NAME} %{VERSION} %{ARCH} %{SIZE} %{VENDOR} %{INSTALLTIME:date}\n"],
                stdout=subprocess.PIPE,
                text=True,
                check=True
            )

            # Parse the output
            for line in result.stdout.strip().split("\n"):
                name, version, arch, size, vendor, install_date = line.strip().split(" ", 5)
                installed_programs.append({
                    "Program_Name": name,
                    "Program_Version": version,
                    "Program_Type": arch,
                    "Program_Hostname": hostname,
                    "Program_Size": size,
                    "Program_Vendor": vendor,
                    "Program_Install_On": install_date,
                    "Program_Package_Manager": "yum/dnf"
                })

        else:
            print("Unsupported package manager")
        sys.stdout.write("Got installed programs\n")
        sys.stdout.write("\n")
        return installed_programs

    except subprocess.CalledProcessError as e:
        print(f"Error occurred while fetching installed programs: {e}")
        return []

def get_system_specs_linux():
    sys.stdout.write("Getting system specifications...\n")
    sys.stdout.write("\n")
    system_specs = {}

    hostname = socket.gethostname()
    # Get OS, version, and vendor
    system_specs["System_OS"] = platform.system()
    system_specs["System_Version"] = platform.release()
    system_specs["System_Vendor"] = platform.platform()

    # Get system hostname
    system_specs["System_Hostname"] = hostname
    system_specs["System_IP"] = socket.gethostbyname(hostname)

    # Get asset type (assuming it's a server)
    system_specs["System_Type"] = "Server"

    # Get installation date
    system_specs["System_Installed_On"] = datetime.fromtimestamp(psutil.boot_time()).strftime("%Y-%m-%d %H:%M:%S")

    # Get uptime
    system_specs["System_Uptime"] = datetime.now() - datetime.fromtimestamp(psutil.boot_time())

    # Get disk size and usage for each disk
    # Get disk size and usage for each disk
    system_specs["System_Disks"] = []
    for partition in psutil.disk_partitions():
        usage = psutil.disk_usage(partition.mountpoint)
        system_specs["System_Disks"].append({
            "Device": partition.device,
            "Mountpoint": partition.mountpoint,
            "Total Size": usage.total,
            "Used Size": usage.used,
            "Free Size": usage.free,
            "Usage %": usage.percent
        })
    
    try:
        sys.stdout.write("system speccs disks: {}\n".format(system_specs["System_Disks"]))
    except Exception as e:
        sys.stdout.write("Error printing system speccs disks :{}".format(e)) 
    # Get total CPU, CPU usage %
    system_specs["System_CPU_Total"] = psutil.cpu_count()
    system_specs["System_CPU_Usage"] = psutil.cpu_percent(interval=1)

    # Get total MEM, MEM usage %
    mem = psutil.virtual_memory()
    system_specs["System_MEM_Total"] = mem.total
    system_specs["System_MEM_Usage"] = mem.percent

    # Get upload and download speeds
    st = speedtest.Speedtest()
    system_specs["System_Speed_Upload"] = st.upload() / 1_000_000  # Convert to Mbps
    system_specs["System_Speed_Download"] = st.download() / 1_000_000  # Convert to Mbps
    sys.stdout.write("Got system specifications\n")
    sys.stdout.write("\n")
    return system_specs

def get_patches_linux():
    sys.stdout.write("Getting patch info...\n")
    sys.stdout.write("\n")
    try:
        patches = []

        # Detect package manager
        package_manager = None
        for manager in ["apt", "yum", "dnf"]:
            if subprocess.run(["which", manager], stdout=subprocess.DEVNULL).returncode == 0:
                package_manager = manager
                break

        if package_manager == "apt":
            # Execute the zgrep command to get patch data from history.log for Debian-based systems
            result = subprocess.run(
                ["zgrep", "Upgrade:", "/var/log/dpkg.log*"],
                stdout=subprocess.PIPE,
                text=True,
                check=True
            )

            # Parse the output
            for line in result.stdout.strip().split("\n"):
                parts = line.strip().split(" ")
                date = " ".join(parts[:2])
                patches.append({
                    "Patch_Date": date,
                    "Patch_Name_ID": parts[-1],
                    "Patch_Package_Manager": "apt"
                })

        elif package_manager in ["yum", "dnf"]:
            # Execute the sudo command to get patch data from yum.log for Red Hat-based systems
            result = subprocess.run(
                ["sudo", "cat", "/var/log/yum.log"],
                stdout=subprocess.PIPE,
                text=True,
                check=True
            )

            # Parse the output
            for line in result.stdout.strip().split("\n"):
                parts = line.strip().split(" ")
                date = " ".join(parts[:3])
                patches.append({
                    "Patch_Date": date,
                    "Patch_Name_ID": parts[-1],
                    "Patch_Package_Manager": "yum/dnf"
                })

        else:
            print("Unsupported package manager")
        sys.stdout.write("Got patch info\n")
        sys.stdout.write("\n")
        return patches

    except subprocess.CalledProcessError as e:
        print(f"Error occurred while fetching patches: {e}")
        return []

def get_running_processes_linux():
    sys.stdout.write("Getting process info...\n")
    sys.stdout.write("\n")
    running_processes = []

    for process in psutil.process_iter(["pid", "name", "username", "cpu_percent", "memory_percent", "create_time"]):
        process_info = {
            "Process_Name": process.info["name"],
            "Process_Type": process.info["username"],
            "Process_Resource_Usage": {
                "CPU": process.info["cpu_percent"],
                "MEM": process.info["memory_percent"]
            },
            "Process_Start_Time": datetime.fromtimestamp(process.info["create_time"]).strftime("%Y-%m-%d %H:%M:%S"),
            "Process_PID": process.info["pid"]
        }

        # Retrieve network communication port
        try:
            connections = process.connections()
            if connections:
                process_info["Process_Network_Communication_Ports"] = [conn.laddr.port for conn in connections if conn.status == "LISTEN"]
        except psutil.AccessDenied:
            pass

        running_processes.append(process_info)
    sys.stdout.write("Got process info\n")
    sys.stdout.write("\n")
    return running_processes

def get_firewall_policies_linux():
    sys.stdout.write("Getting firewall policies...\n")
    sys.stdout.write("\n")
    firewall_policies = []

    # Detect firewall software
    firewall_software = None
    for software in ["iptables", "nft"]:
        if subprocess.run(["which", software], stdout=subprocess.DEVNULL).returncode == 0:
            firewall_software = software
            break

    if firewall_software == "iptables":
        # Execute the iptables command for older Linux systems
        result = subprocess.run(
            ["sudo", "iptables", "-L", "-n", "-v"],
            stdout=subprocess.PIPE,
            text=True,
            check=True
        )

        # Parse the output
        current_chain = None
        for line in result.stdout.strip().split("\n"):
            if "Chain" in line and "policy" in line:
                current_chain = line.split(" ")[1]
            elif "pkts" in line:
                parts = line.strip().split()
                firewall_policies.append({
                    "Policy_Name": current_chain,
                    "Policy_Type": "iptables",
                    "Policy_Source": parts[-2],
                    "Policy_Destination": parts[-1],
                    "Policy_Protocol": parts[2],
                    "Policy_Ports": parts[-3]
                })

    elif firewall_software == "nft":
        # Execute the nft command for newer Linux systems
        result = subprocess.run(
            ["sudo", "nft", "list", "ruleset"],
            stdout=subprocess.PIPE,
            text=True,
            check=True
        )

        # Parse the output
        current_chain = None
        for line in result.stdout.strip().split("\n"):
            if "chain" in line:
                current_chain = line.split(" ")[-1].strip()
            elif "ip" in line:
                parts = line.strip().split()
                protocol = parts[2]
                source = parts[-2]
                destination = parts[-1]
                ports = ",".join(parts[6:-3])
                firewall_policies.append({
                    "Policy_Name": current_chain,
                    "Policy_Type": "nftables",
                    "Policy_Source": source,
                    "Policy_Destination": destination,
                    "Policy_Protocol": protocol,
                    "Policy_Ports": ports
                })

    else:
        print("Unsupported firewall software\n")
    sys.stdout.write("Got firewall policies\n")
    sys.stdout.write("\n")
    return firewall_policies

def save_data_to_postgres(customer_info ,installed_programs, system_specs, patches, running_processes, firewall_policies):
    sys.stdout.write("Saving data to database...\n")
    sys.stdout.write("\n")
    # Connection parameters - replace with your actual parameters
    conn = psycopg2.connect(
        dbname=db_name, 
        user=db_user, 
        password=db_pass, 
        host=db_host, 
        port=db_port
    )

    cur = conn.cursor()
    sys.stdout.write("Connected to database\n")
    sys.stdout.write("\n")
    hostname = socket.gethostname()
    ip_address = socket.gethostbyname(hostname)


    OS = platform.system()
    system_specs["Version"] = platform.release()
    Vendor = platform.platform()
    Installed_On = datetime.fromtimestamp(psutil.boot_time()).strftime("%Y-%m-%d %H:%M:%S")

    # Inserting data into customer_info table from config.yml
    customer_info["Customer_Name"] = CUSTOMER  # Add customer name to system_specs dict
    cur.execute(
        sql.SQL("INSERT INTO system_specs ({}) VALUES ({})").format(
            sql.SQL(', ').join(map(sql.Identifier, customer_info.keys())),
            sql.SQL(', ').join(map(sql.Placeholder, customer_info.keys()))
        ),
        list(customer_info.values())
    )


    # Inserting data into asset table
    cur.execute(
        "INSERT INTO asset (Asset_Name, Asset_Vendor, Asset_OS, Asset_IP, Installed_On, Asset_Type, Customer_Name) VALUES (%s, %s, %s, %s, %s, %s, %s)",
        (hostname, Vendor, OS, ip_address, Installed_On, "Server", CUSTOMER)
    )

    
    # Inserting data into programs table
    for program in installed_programs:
        cur.execute(
            "INSERT INTO programs (Program_Name, Program_Version, Program_Type, Program_Install_Date, Program_Hostname, Program_Size, Program_Vendor, Program_Package_Manager, Customer_Name) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
            (program['Program_Name'], program['Program_Version'], program['Program_Type'], program['Program_Install Date'], hostname, program['Program_Size'], program['Program_Vendor'], program['Program_Package Manager'], CUSTOMER)
        )

    # Inserting data into system_specs table
    system_specs["Customer_Name"] = CUSTOMER  # Add customer name to system_specs dict
    cur.execute(
        sql.SQL("INSERT INTO system_specs ({}) VALUES ({})").format(
            sql.SQL(', ').join(map(sql.Identifier, system_specs.keys())),
            sql.SQL(', ').join(map(sql.Placeholder, system_specs.keys()))
        ),
        list(system_specs.values())
    )

    # Inserting data into patches table
    for patch in patches:
        cur.execute(
            "INSERT INTO patches (Patch_Name_ID, Patch_Date, Patch_Package_Manager, Customer_Name) VALUES (%s, %s, %s, %s)",
            (patch['Patch_Name_ID'], patch['Patch_Date'], patch['Patch_Package_Manager'], CUSTOMER)
        )

    # Inserting data into processes table
    for process in running_processes:
        cur.execute(
            "INSERT INTO processes (Process_Name, Process_Type, Process_Resource_Usage, Process_Start_Time, Process_PID, Process_Network_Communication_Ports, Customer_Name) VALUES (%s, %s, %s, %s, %s, %s, %s)",
            (process['Process_Name'], process['Process_Type'], process['Process_Resource_Usage'], process['Process_Start_Time'], process['Process_PID'], process['Process_Network_Communication_Ports'], CUSTOMER)
        )

    # Inserting data into firewall table
    for policy in firewall_policies:
        cur.execute(
            "INSERT INTO firewall (Policy_Name, Policy_Type, Policy_Source, Policy_Destination, Policy_Protocol, Policy_Ports, Policy_Customer_Name) VALUES (%s, %s, %s, %s, %s, %s, %s)",
            (policy['Policy_Name'], policy['Policy_Type'], policy['Policy_Source'], policy['Policy_Destination'], policy['Policy_Protocol'], policy['Policy_Ports'], CUSTOMER)
        )

    # Commit the transaction
    conn.commit()
    sys.stdout.write("Done inserting data to database\n")
    sys.stdout.write("\n")
    # Close the connection
    cur.close()
    conn.close()
    sys.stdout.write("Closed connection to database\n")
    sys.stdout.write("\n")


def save_data_to_json(customer_info, installed_programs, system_specs, patches, running_processes, firewall_policies, network_discovery):
    sys.stdout.write("Saving data to JSON file...\n")
    sys.stdout.write("\n")

    # Prepare data to be saved to JSON file
    data = {
        'customer_info': customer_info,
        'installed_programs': installed_programs,
        'system_specs': system_specs,
        'patches': patches,
        'running_processes': running_processes,
        'firewall_policies': firewall_policies,
        'network_discovery': network_discovery.to_dict('records')
    }

    # JSON filename should be $customername + .json
    filename = f"{CUSTOMER}_{socket.gethostname()}.json"
    
    # Save data to JSON file
    with open(filename, 'w') as jsonfile:
        json.dump(data, jsonfile, default=str)  # default=str for datetime objects

    sys.stdout.write("Saved data to JSON file\n")
    sys.stdout.write("\n")
    return filename

def upload_to_cloud(zipfilename):
    sys.stdout.write("Uploading csv data to Azure Blob Storage...\n")
    sys.stdout.write("\n")
    # Use the function
    connection_string = "<your_azure_blob_storage_connection_string>"
    # Example:
    # connection_string = "DefaultEndpointsProtocol=https;AccountName=<your_azure_storage_account_name>;AccountKey=<your_azure_storage_account_key>"
    container_name = "<your_azure_blob_storage_container_name>"
    local_file = zipfilename
    blob_name = zipfilename
    try:
        # Create a BlobServiceClient using the provided connection string
        blob_service_client = BlobServiceClient.from_connection_string(connection_string)

        # Get a reference to the container where the blob will be uploaded
        container_client = blob_service_client.get_container_client(container_name)

        # Upload the local file to the specified blob
        with open(local_file, "rb") as data:
            container_client.upload_blob(blob_name, data)

        print(f"Uploaded {local_file} to Azure Blob Storage as {blob_name}")
        sys.stdout.write("Uploaded csv data to Azure Blob Storage\n")
        sys.stdout.write("\n")
    except Exception as e:
        print(f"Error occurred while uploading to Azure Blob Storage: {e}")

def get_api_key(api_key: str = Depends(api_key_header)):
    if api_key != API_KEY:
        raise HTTPException(
            status_code=HTTP_403_FORBIDDEN, detail="Invalid API key"
        )
    return api_key

# FastAPI endpoints for live data
@app.get("/manager/live/cpu", dependencies=[Depends(get_api_key)])
def get_live_cpu_usage():
    cpu_percent = psutil.cpu_percent()
    return {"cpu_percent": cpu_percent}

def get_live_memory_usage():
    memory_info = psutil.virtual_memory()
    return {
        "total_memory": memory_info.total,
        "used_memory": memory_info.used,
        "free_memory": memory_info.free,
        "memory_percent": memory_info.percent,
    }

@app.get("/manager/live/upload_speed", dependencies=[Depends(get_api_key)])
def get_live_upload_speed():
    speed_test = speedtest.Speedtest()
    speed_test.get_best_server()
    upload_speed = speed_test.upload() / 1_000_000  # Convert bits to megabits

    return {"upload_speed_mbps": upload_speed}

@app.get("/manager/live/download_speed", dependencies=[Depends(get_api_key)])
def get_live_download_speed():
    speed_test = speedtest.Speedtest()
    speed_test.get_best_server()
    download_speed = speed_test.download() / 1_000_000  # Convert bits to megabits

    return {"download_speed_mbps": download_speed}

@app.get("/manager/live/disk", dependencies=[Depends(get_api_key)])
def get_live_disk_usage():
    disk_usage_info = psutil.disk_usage('/')
    return {
        "total_disk": disk_usage_info.total,
        "used_disk": disk_usage_info.used,
        "free_disk": disk_usage_info.free,
        "disk_percent": disk_usage_info.percent,
    }

@app.get("/manager/data")
async def read_customer_data():
    # Gather all the required data.
    customer_info = Get_Customer_info()
    network_discovery = NetworkDiscovery()
    installed_programs = get_installed_programs_linux()
    system_specs = get_system_specs_linux()
    patches = get_patches_linux()
    running_processes = get_running_processes_linux()
    firewall_policies = get_firewall_policies_linux()

    # Save data to json
    filename = save_data_to_json(customer_info ,installed_programs, system_specs, patches, running_processes, firewall_policies, network_discovery)
    
    # Read the json file and return as a response.
    with open(filename, 'r') as file:
        data = json.load(file)

    return data

@app.post("/upload")
async def upload_zipfile(file: UploadFile = File(...)):
    try:
        sys.stdout.write(f"CYLOPSE_MANAGER: Incomming file: '{file.filename}'...\n")
        sys.stdout.write("\n")
        # Make sure the upload directory exists
        upload_dir = "/tmp"
        os.makedirs(upload_dir, exist_ok=True)

        # Write the file to disk
        with open(os.path.join(upload_dir, file.filename), "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        sys.stdout.write(f"CYLOPSE_MANAGER: File '{file.filename}' uploaded successfully\n")
        sys.stdout.write("\n")
        return JSONResponse(status_code=200, content={"message": f"File '{file.filename}' uploaded successfully"})
    except Exception as e:
        sys.stdout.write(f"CYLOPSE_MANAGER: File '{file.filename}' upload failed - Error: {e}\n")
        return JSONResponse(status_code=500, content={"message": str(e)})
    
@app.get("/manager/customers")
async def unzip_json_files():
    json_files = []
    directory = "/cyclopse_data"
    
    # Iterate over all the files in the directory
    for file_name in os.listdir(directory):
        file_path = os.path.join(directory, file_name)
        
        # Check if the file is a zip file
        if zipfile.is_zipfile(file_path):
            # Open the zip file
            with zipfile.ZipFile(file_path, 'r') as zip_ref:
                # Extract only the .json files
                for name in zip_ref.namelist():
                    if name.lower().endswith('.json'):
                        # Extract the file
                        zip_ref.extract(name, path=directory)
                        # Add the filename to the array
                        json_files.append(name)
    
    return json_files

# Database route that return expected json:
def get_db():
    try:
        db = SessionLocal()
        yield db
    finally:
        db.close()

@app.get("/customer/{customer_name}")
def get_customer_info(customer_name: str, db: Session = Depends(get_db)):
    customer_info = db.query(CustomerInfo).filter(CustomerInfo.Customer_Name == customer_name).first()
    if not customer_info:
        raise HTTPException(status_code=404, detail="Customer not found")

    assets = db.query(Asset).filter(Asset.Customer_Name == customer_name).all()
    system_specs = db.query(SystemSpecs).filter(SystemSpecs.Customer_Name == customer_name).all()
    programs = db.query(Programs).filter(Programs.Customer_Name == customer_name).all()
    processes = db.query(Processes).filter(Processes.Customer_Name == customer_name).all()
    patches = db.query(Patches).filter(Patches.Customer_Name == customer_name).all()
    firewalls = db.query(Firewall).filter(Firewall.Customer_Name == customer_name).all()
    Network_discovery = db.query(Firewall).filter(NetworkDiscovery.Customer_Name == customer_name).all()
    audit = db.query(Firewall).filter(Audit.Customer_Name == customer_name).all()

    return {
        "customer_info": customer_info,
        "assets": assets,
        "system_specs": system_specs,
        "programs": programs,
        "processes": processes,
        "patches": patches,
        "firewalls": firewalls,
        "network_discovery": Network_discovery,
        "audit": audit
    }

@app.get("/test/config")
def test():
    db_info = {"name": db_name, "user": db_user, "pass": db_pass, "host": db_host, "port": db_port}
    config = {"db_info": db_info}
    return {"config": config}
    
@app.get("/test/customer_info")
def test():
    customer_info = Get_Customer_info()
    return {"customer_info": customer_info}
 
@app.get("/test/network_discovery")
def test():
    network_discovery = NetworkDiscovery()
    return {"network_discovery": network_discovery}

@app.get("/test/installed_programs")
def test():
    installed_programs = get_installed_programs_linux()
    return {"installed_programs": installed_programs}

@app.get("/test/system_specs")
def test():
    system_specs = get_system_specs_linux()
    return {"system_specs": system_specs}

@app.get("/test/patches")
def test():
    patches = get_patches_linux()
    return {"patches": patches}

@app.get("/test/running_processes")
def test():
    running_processes = get_running_processes_linux()
    return {"running_processes": running_processes}

@app.get("/test/firewall_policies")
def test():
    firewall_policies = get_firewall_policies_linux()
    return {"firewall_policies": firewall_policies}




    