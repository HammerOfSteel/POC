import pandas as pd
import os
import sys
import csv
import zipfile
import platform
import subprocess
import socket
from datetime import datetime
import psutil
import speedtest
import requests
import psycopg2
from psycopg2 import sql
from fastapi import FastAPI, Depends, HTTPException
from fastapi.security import APIKeyHeader
from starlette.status import HTTP_403_FORBIDDEN
from azure.storage.blob import BlobServiceClient
import yaml
import json
from scapy.all import ARP, Ether, srp
from manuf import manuf
from typing import Optional
import nmap3
import time
import requests
import os
from scapy.all import ARP, Ether, srp


def read_db_config():
    with open("config.yml", 'r') as stream:
        try:
            config = yaml.safe_load(stream)
            db_config = config['database']
            return db_config
        except yaml.YAMLError as exc:
            print(exc)

def read_manager_config():
    with open("config.yml", 'r') as stream:
        try:
            config = yaml.safe_load(stream)
            ma_config = config['manager']
            return ma_config
        except yaml.YAMLError as exc:
            print(exc)

def read_api_config():
    with open("config.yml", 'r') as stream:
        try:
            config = yaml.safe_load(stream)
            api_config = config['api']
            return api_config
        except yaml.YAMLError as exc:
            print(exc)

def read_customer_config():
    with open("config.yml", 'r') as stream:
        try:
            config = yaml.safe_load(stream)
            customer_config = config['customer']
            return customer_config
        except yaml.YAMLError as exc:
            print(exc)

db_config = read_db_config()
api_config = read_api_config()
customer_config = read_customer_config()
ma_config = read_manager_config()

db_name = db_config['db_name']
db_user = db_config['db_user']
db_pass = db_config['db_pass']
db_host = db_config['db_host']
db_port = db_config['db_port']

manager_hostname = ma_config['ma_hostname']
manager_ip = ma_config['ma_ip']
manager_port = ma_config['ma_port']
manager_user = ma_config['ma_user']
manager_pass = ma_config['ma_pass']
manager_POC = ma_config['ma_POC']

CUSTOMER = customer_config['name']
CUSTOMER_EMAIL = customer_config['email']
CUSTOMER_PHONE = customer_config['phone']

def POC_RUN():
    customer_info = Get_Customer_info()
    network_discovery = NetworkDiscovery()
    installed_programs = get_installed_programs_linux()
    system_specs = get_system_specs_linux()
    patches = get_patches_linux()
    running_processes = get_running_processes_linux()
    firewall_policies = get_firewall_policies_linux()
    zipfilename = save_data_to_csv_linux(customer_info ,installed_programs, system_specs, patches, running_processes, firewall_policies, network_discovery)
    return zipfilename

def upload_to_manager(file_path):
    sys.stdout.write("Uploading data to cyclopse manager server...\n")
    sys.stdout.write("\n")
    # Make sure the file exists before trying to upload it
    if not os.path.isfile(file_path):
        print(f"The file '{file_path}' does not exist.")
        sys.stdout.write(f"The file '{file_path}' does not exist.")
        sys.stdout.write("\n")
        return

    # Open the file in binary mode
    with open(file_path, 'rb') as file:
        # Set up the data dictionary
        file_dict = {'file': (os.path.basename(file_path), file, 'application/zip')}

        # Send the POST request
        response = requests.post(f"http://{manager_hostname}:{manager_port}/upload", files=file_dict)

    if response.status_code == 200:
        print(f"File '{file_path}' successfully uploaded.")
        sys.stdout.write(f"Uploaded data: '{file_path}' to cyclopse manager server successfully\n")
        sys.stdout.write("\n")
    else:
        print(f"Failed to upload '{file_path}'. Server responded with: {response.content}")
        sys.stdout.write(f"Failed to upload '{file_path}' to cyclopse manager server. Manager server responded with: {response.content}")
        sys.stdout.write("\n")

# Define API key and FastAPI app
API_KEY = api_config['key']
api_key_header = APIKeyHeader(name="api_key", auto_error=True)
app = FastAPI()

def Get_Customer_info():
    sys.stdout.write("Getting customer info...\n")
    sys.stdout.write("\n")
    customer_info = {}
    customer_info["Customer_Name"] = CUSTOMER
    customer_info["Customer_Email"] = CUSTOMER_EMAIL
    customer_info["Customer_Phone"] = CUSTOMER_PHONE
    sys.stdout.write("Got customer info\n")
    sys.stdout.write("\n")
    return customer_info

def nmap_discovery():
    network = socket.gethostbyname(socket.gethostname()) + "/24"
    nmap = nmap3.Nmap()
    results = nmap.scan_top_ports(network)

    assets = []
    for ip, info in results.items():
        asset = {
            "ip": ip,
            "hostname": info.get("hostname", ""),
            "details": info.get("ports", [])
        }
        assets.append(asset)

    return json.dumps(assets, indent=4)

def NetworkDiscovery():
    sys.stdout.write("Doing network discovery...\n")
    sys.stdout.write("\n")
    p = manuf.MacParser()
    alias = socket.gethostname()
    customerNameArr = []
    FirewallVendorArr = []
    HostDiscovery = []
    HostResourcesArr = []
    Networkdiscovery = pd.DataFrame()
    IPV4Arr = []
    StatusArr = []
    FQDNArr = []
    HostnameArr = []
    AliasArr = []
    MACArr = []
    VendorArr = []
    customerNameArr = []
    host_name = socket.gethostname()
    Host = socket.gethostbyname(host_name)
    target_ip = Host+"/24"
    from scapy.all import ARP, Ether, srp

    #target_ip = "192.168.1.1/24"
    # IP Address for the destination
    # create ARP packet
    arp = ARP(pdst=target_ip)
    # create the Ether broadcast packet
    # ff:ff:ff:ff:ff:ff MAC address indicates broadcasting
    ether = Ether(dst="ff:ff:ff:ff:ff:ff")
    # stack them
    packet = ether/arp

    result = srp(packet, timeout=3, verbose=0)[0]

    # a list of clients, we will fill this in the upcoming loop
    clients = []

    for sent, received in result:
        # for each response, append ip and mac address to `clients` list
        clients.append({'ip': received.psrc, 'mac': received.hwsrc})

    # print clients
    for client in clients:
        customerNameArr.append(CUSTOMER)
        AliasArr.append(host_name)
        HostnameArr.append(alias)
        StatusArr.append("Up")
        MACArr.append(client['mac'])
        IPV4Arr.append(client['ip'])
        try:
            sys.stdout.write("Mac: {}".format(client['mac']))
            vendor = p.get_manuf(client['mac'])
            sys.stdout.write("Vendor: {}".format(vendor))
        except Exception as e:
            sys.stdout.write("Error on getting vendor: {}".format(e))
            sys.stdout.write("Mac was: {}".format(client['mac']))
            vendor = "Default"
        VendorArr.append(vendor)

    Networkdiscovery['Networkdiscovery_customer_name'] = pd.Series(customerNameArr)
    Networkdiscovery['Networkdiscovery_IP'] = pd.Series(IPV4Arr)
    Networkdiscovery['Networkdiscovery_Status'] = pd.Series(StatusArr)
    Networkdiscovery['Networkdiscovery_FQDN'] = pd.Series(HostnameArr)
    Networkdiscovery['Networkdiscovery_MAC'] = pd.Series(MACArr)
    Networkdiscovery['Networkdiscovery_Vendor'] = pd.Series(VendorArr)
    Networkdiscovery['Networkdiscovery_Hostname'] = pd.Series(HostnameArr)
    Networkdiscovery['Networkdiscovery_Alias'] = pd.Series(HostnameArr)
    sys.stdout.write("Completed network discovery\n")
    sys.stdout.write("\n")
    return Networkdiscovery

def get_installed_programs_linux():
    sys.stdout.write("Getting installed programs...\n")
    sys.stdout.write("\n")
    try:
        installed_programs = []

        # Get the system hostname
        hostname = socket.gethostname()

        # Detect package manager
        package_manager = None
        for manager in ["apt", "yum", "dnf"]:
            if subprocess.run(["which", manager], stdout=subprocess.DEVNULL).returncode == 0:
                package_manager = manager
                break

        if package_manager == "apt":
            # Execute the dpkg-query command for Debian-based systems
            result = subprocess.run(
                ["dpkg-query", "-W", "-f=${binary:Package} ${Version} ${Architecture} ${Installed-Size} ${Maintainer}\n"],
                stdout=subprocess.PIPE,
                text=True,
                check=True
            )

            # Parse the output
            for line in result.stdout.strip().split("\n"):
                name, version, arch, size, vendor = line.strip().split(" ", 4)
                # Get the modification time of the .list file as the install date
                list_file = f"/var/lib/dpkg/info/{name}.list"
                install_date = ''
                if os.path.isfile(list_file):
                    timestamp = os.path.getmtime(list_file)
                    install_date = datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')
                installed_programs.append({
                    "Program_Name": name,
                    "Program_Version": version,
                    "Program_Type": arch,
                    "Program_Hostname": hostname,
                    "Program_Size": size,
                    "Program_Vendor": vendor,
                    "Program_Install_On": install_date,
                    "Program_Package_Manager": "apt"
                })

        elif package_manager in ["yum", "dnf"]:
            # Execute the rpm command for Red Hat-based systems
            result = subprocess.run(
                ["rpm", "-qa", "--queryformat", "%{NAME} %{VERSION} %{ARCH} %{SIZE} %{VENDOR} %{INSTALLTIME:date}\n"],
                stdout=subprocess.PIPE,
                text=True,
                check=True
            )

            # Parse the output
            for line in result.stdout.strip().split("\n"):
                name, version, arch, size, vendor, install_date = line.strip().split(" ", 5)
                installed_programs.append({
                    "Program_Name": name,
                    "Program_Version": version,
                    "Program_Type": arch,
                    "Program_Hostname": hostname,
                    "Program_Size": size,
                    "Program_Vendor": vendor,
                    "Program_Install_On": install_date,
                    "Program_Package_Manager": "yum/dnf"
                })

        else:
            print("Unsupported package manager")
        sys.stdout.write("Got installed programs\n")
        sys.stdout.write("\n")
        return installed_programs

    except subprocess.CalledProcessError as e:
        print(f"Error occurred while fetching installed programs: {e}")
        return []

def get_system_specs_linux():
    sys.stdout.write("Getting system specifications...\n")
    sys.stdout.write("\n")
    system_specs = {}

    hostname = socket.gethostname()
    # Get OS, version, and vendor
    system_specs["System_OS"] = platform.system()
    system_specs["System_Version"] = platform.release()
    system_specs["System_Vendor"] = platform.platform()

    # Get system hostname
    system_specs["System_Hostname"] = hostname
    system_specs["System_IP"] = socket.gethostbyname(hostname)

    # Get asset type (assuming it's a server)
    system_specs["System_Type"] = "Server"

    # Get installation date
    system_specs["System_Installed_On"] = datetime.fromtimestamp(psutil.boot_time()).strftime("%Y-%m-%d %H:%M:%S")

    # Get uptime
    system_specs["System_Uptime"] = datetime.now() - datetime.fromtimestamp(psutil.boot_time())

    # Get disk size and usage for each disk
    # Get disk size and usage for each disk
    system_specs["System_Disks"] = []
    for partition in psutil.disk_partitions():
        usage = psutil.disk_usage(partition.mountpoint)
        system_specs["System_Disks"].append({
            "Device": partition.device,
            "Mountpoint": partition.mountpoint,
            "Total Size": usage.total,
            "Used Size": usage.used,
            "Free Size": usage.free,
            "Usage %": usage.percent
        })

    try:
        sys.stdout.write("system speccs disks: {}\n".format(system_specs["System_Disks"]))
    except Exception as e:
        sys.stdout.write("Error printing system speccs disks :{}".format(e))
    # Get total CPU, CPU usage %
    system_specs["System_CPU_Total"] = psutil.cpu_count()
    system_specs["System_CPU_Usage"] = psutil.cpu_percent(interval=1)

    # Get total MEM, MEM usage %
    mem = psutil.virtual_memory()
    system_specs["System_MEM_Total"] = mem.total
    system_specs["System_MEM_Usage"] = mem.percent

    # Get upload and download speeds
    st = speedtest.Speedtest()
    system_specs["System_Speed_Upload"] = st.upload() / 1_000_000  # Convert to Mbps
    system_specs["System_Speed_Download"] = st.download() / 1_000_000  # Convert to Mbps
    sys.stdout.write("Got system specifications\n")
    sys.stdout.write("\n")
    return system_specs

def get_patches_linux():
    sys.stdout.write("Getting patch info...\n")
    sys.stdout.write("\n")
    try:
        patches = []

        # Detect package manager
        package_manager = None
        for manager in ["apt", "yum", "dnf"]:
            if subprocess.run(["which", manager], stdout=subprocess.DEVNULL).returncode == 0:
                package_manager = manager
                break

        if package_manager == "apt":
            # Execute the zgrep command to get patch data from history.log for Debian-based systems
            result = subprocess.run(
                ["zgrep", "Upgrade:", "/var/log/dpkg.log*"],
                stdout=subprocess.PIPE,
                text=True,
                check=True
            )

            # Parse the output
            for line in result.stdout.strip().split("\n"):
                parts = line.strip().split(" ")
                date = " ".join(parts[:2])
                patches.append({
                    "Patch_Date": date,
                    "Patch_Name_ID": parts[-1],
                    "Patch_Package_Manager": "apt"
                })

        elif package_manager in ["yum", "dnf"]:
            # Execute the sudo command to get patch data from yum.log for Red Hat-based systems
            result = subprocess.run(
                ["sudo", "cat", "/var/log/yum.log"],
                stdout=subprocess.PIPE,
                text=True,
                check=True
            )

            # Parse the output
            for line in result.stdout.strip().split("\n"):
                parts = line.strip().split(" ")
                date = " ".join(parts[:3])
                patches.append({
                    "Patch_Date": date,
                    "Patch_Name_ID": parts[-1],
                    "Patch_Package_Manager": "yum/dnf"
                })

        else:
            print("Unsupported package manager")
        sys.stdout.write("Got patch info\n")
        sys.stdout.write("\n")
        return patches

    except subprocess.CalledProcessError as e:
        print(f"Error occurred while fetching patches: {e}")
        return []

def get_running_processes_linux():
    sys.stdout.write("Getting process info...\n")
    sys.stdout.write("\n")
    running_processes = []

    for process in psutil.process_iter(["pid", "name", "username", "cpu_percent", "memory_percent", "create_time"]):
        process_info = {
            "Process_Name": process.info["name"],
            "Process_Type": process.info["username"],
            "Process_Resource_Usage": {
                "CPU": process.info["cpu_percent"],
                "MEM": process.info["memory_percent"]
            },
            "Process_Start_Time": datetime.fromtimestamp(process.info["create_time"]).strftime("%Y-%m-%d %H:%M:%S"),
            "Process_PID": process.info["pid"],
            "Process_Network_Communication_Ports": ""
        }

        # Retrieve network communication port
        try:
            connections = process.connections()
            if connections:
                portArr = [conn.laddr.port for conn in connections if conn.status == "LISTEN"]
            try:
                process_info["Process_Network_Communication_Ports"] = ','.join(map(str, portArr))
            except:
                process_info["Process_Network_Communication_Ports"] = ""
        except psutil.AccessDenied:
            pass

        running_processes.append(process_info)
    sys.stdout.write("Got process info\n")
    sys.stdout.write("\n")
    return running_processes

def get_firewall_policies_linux():
    sys.stdout.write("Getting firewall policies...\n")
    sys.stdout.write("\n")
    firewall_policies = []

    # Detect firewall software
    firewall_software = None
    for software in ["iptables", "nft"]:
        if subprocess.run(["which", software], stdout=subprocess.DEVNULL).returncode == 0:
            firewall_software = software
            break

    if firewall_software == "iptables":
        # Execute the iptables command for older Linux systems
        result = subprocess.run(
            ["sudo", "iptables", "-L", "-n", "-v"],
            stdout=subprocess.PIPE,
            text=True,
            check=True
        )

        # Parse the output
        current_chain = None
        for line in result.stdout.strip().split("\n"):
            if "Chain" in line and "policy" in line:
                current_chain = line.split(" ")[1]
            elif "pkts" in line:
                parts = line.strip().split()
                firewall_policies.append({
                    "Policy_Name": current_chain,
                    "Policy_Type": "iptables",
                    "Policy_Source": parts[-2],
                    "Policy_Destination": parts[-1],
                    "Policy_Protocol": parts[2],
                    "Policy_Ports": parts[-3]
                })

    elif firewall_software == "nft":
        # Execute the nft command for newer Linux systems
        result = subprocess.run(
            ["sudo", "nft", "list", "ruleset"],
            stdout=subprocess.PIPE,
            text=True,
            check=True
        )

        # Parse the output
        current_chain = None
        for line in result.stdout.strip().split("\n"):
            if "chain" in line:
                current_chain = line.split(" ")[-1].strip()
            elif "ip" in line:
                parts = line.strip().split()
                protocol = parts[2]
                source = parts[-2]
                destination = parts[-1]
                ports = ",".join(parts[6:-3])
                firewall_policies.append({
                    "Policy_Name": current_chain,
                    "Policy_Type": "nftables",
                    "Policy_Source": source,
                    "Policy_Destination": destination,
                    "Policy_Protocol": protocol,
                    "Policy_Ports": ports
                })

    else:
        print("Unsupported firewall software\n")
    sys.stdout.write("Got firewall policies\n")
    sys.stdout.write("\n")
    return firewall_policies

def save_data_to_csv_linux(customer_info ,installed_programs, system_specs, patches, running_processes, firewall_policies, Network_discovery):
    sys.stdout.write("Saving csv data to zip archive...\n")
    sys.stdout.write("\n")
    # Save data to individual CSV files
    # zip filename should be $hostsname + $datetime + .zip
    TODAY = datetime.now().strftime("%Y_%m_%d_%H_%M_%S")
    hostname = socket.gethostname()
    zipfilename = f"/cyclopse_data/{hostname}_{TODAY}.zip"
    filenames = []

    with open("customer_info.csv", "w", newline="") as csvfile:
        fieldnames = list(customer_info.keys())
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerow(customer_info)
    filenames.append("customer_info.csv")

    try:
        with open("programs.csv", "w", newline="") as csvfile:
            # Use the keys of the first dictionary in installed_programs as the fieldnames
            # This assumes that all dictionaries in installed_programs have the same keys
            fieldnames = installed_programs[0].keys() if installed_programs else []
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(installed_programs)
        filenames.append("programs.csv")
    except Exception as e:
        print(f"An error occurred: {e}")
        with open("programs_error_dump.csv", "w") as f:
            f.write(str(installed_programs))


    with open("system.csv", "w", newline="") as csvfile:
        fieldnames = list(system_specs.keys())
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerow(system_specs)
    filenames.append("system.csv")

    with open("patches.csv", "w", newline="") as csvfile:
        fieldnames = ["Patches_Name_ID", "Patches_Date", "Patches_Package_Manager"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(patches)
    filenames.append("patches.csv")

    with open("processes.csv", "w", newline="") as csvfile:
        fieldnames = ["Process_Name", "Process_Type", "Process_Resource_Usage", "Process_Start_Time", "Process_PID", "Process_Network_Communication_Ports"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(running_processes)
    filenames.append("processes.csv")

    with open("firewall.csv", "w", newline="") as csvfile:
        fieldnames = ["Policy_Name", "Policy_Type", "Policy_Source", "Policy_Destination", "Policy_Protocol", "Policy_Ports"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(firewall_policies)
    filenames.append("firewall.csv")

    ND = Network_discovery
    ND.to_csv('network_discovery.csv', index=False)  # index=False prevents pandas from writing row indices
    filenames.append("network_discovery.csv")

    try:
        jsonfile = save_data_to_json(customer_info, installed_programs, system_specs, patches, running_processes, firewall_policies, Network_discovery)
        filenames.append(jsonfile)
    except Exception as e:
        sys.stdout.write(f"Error saving json file: {e}\n")
        sys.stdout.write("\n")


    # Create a zip archive containing all the CSV files
    with zipfile.ZipFile(zipfilename, "w", zipfile.ZIP_DEFLATED) as archive:
        for filename in filenames:
            archive.write(filename)
    sys.stdout.write("Saves csv data to zip archive\n")
    sys.stdout.write("\n")
    return zipfilename

def save_data_to_json(customer_info, installed_programs, system_specs, patches, running_processes, firewall_policies, network_discovery):
    sys.stdout.write("Saving data to JSON file...\n")
    sys.stdout.write("\n")

    # Prepare data to be saved to JSON file
    data = {
        'customer_info': customer_info,
        'installed_programs': installed_programs,
        'system_specs': system_specs,
        'patches': patches,
        'running_processes': running_processes,
        'firewall_policies': firewall_policies,
        'network_discovery': network_discovery.to_dict('records')
    }

    # JSON filename should be $customername + .json
    filename = f"{CUSTOMER}_{socket.gethostname()}.json"

    # Save data to JSON file
    with open(filename, 'w') as jsonfile:
        json.dump(data, jsonfile, default=str)  # default=str for datetime objects

    sys.stdout.write("Saved data to JSON file\n")
    sys.stdout.write("\n")
    return filename

def upload_to_cloud(zipfilename):
    sys.stdout.write("Uploading csv data to Azure Blob Storage...\n")
    sys.stdout.write("\n")
    # Use the function
    connection_string = "<your_azure_blob_storage_connection_string>"
    # Example:
    # connection_string = "DefaultEndpointsProtocol=https;AccountName=<your_azure_storage_account_name>;AccountKey=<your_azure_storage_account_key>"
    container_name = "<your_azure_blob_storage_container_name>"
    local_file = zipfilename
    blob_name = zipfilename
    try:
        # Create a BlobServiceClient using the provided connection string
        blob_service_client = BlobServiceClient.from_connection_string(connection_string)

        # Get a reference to the container where the blob will be uploaded
        container_client = blob_service_client.get_container_client(container_name)

        # Upload the local file to the specified blob
        with open(local_file, "rb") as data:
            container_client.upload_blob(blob_name, data)

        print(f"Uploaded {local_file} to Azure Blob Storage as {blob_name}")
        sys.stdout.write("Uploaded csv data to Azure Blob Storage\n")
        sys.stdout.write("\n")
    except Exception as e:
        print(f"Error occurred while uploading to Azure Blob Storage: {e}")

def get_api_key(api_key: str = Depends(api_key_header)):
    if api_key != API_KEY:
        raise HTTPException(
            status_code=HTTP_403_FORBIDDEN, detail="Invalid API key"
        )
    return api_key

# FastAPI endpoints for live data
@app.get("/live/cpu", dependencies=[Depends(get_api_key)])
def get_live_cpu_usage():
    cpu_percent = psutil.cpu_percent()
    return {"cpu_percent": cpu_percent}

def get_live_memory_usage():
    memory_info = psutil.virtual_memory()
    return {
        "total_memory": memory_info.total,
        "used_memory": memory_info.used,
        "free_memory": memory_info.free,
        "memory_percent": memory_info.percent,
    }

@app.get("/live/upload_speed", dependencies=[Depends(get_api_key)])
def get_live_upload_speed():
    speed_test = speedtest.Speedtest()
    speed_test.get_best_server()
    upload_speed = speed_test.upload() / 1_000_000  # Convert bits to megabits

    return {"upload_speed_mbps": upload_speed}

@app.get("/live/download_speed", dependencies=[Depends(get_api_key)])
def get_live_download_speed():
    speed_test = speedtest.Speedtest()
    speed_test.get_best_server()
    download_speed = speed_test.download() / 1_000_000  # Convert bits to megabits

    return {"download_speed_mbps": download_speed}

@app.get("/live/disk", dependencies=[Depends(get_api_key)])
def get_live_disk_usage():
    disk_usage_info = psutil.disk_usage('/')
    return {
        "total_disk": disk_usage_info.total,
        "used_disk": disk_usage_info.used,
        "free_disk": disk_usage_info.free,
        "disk_percent": disk_usage_info.percent,
    }

@app.get("/customer/{customer_name}")
async def read_customer_data(customer_name: str):
    # Gather all the required data.
    customer_info = Get_Customer_info()
    network_discovery = NetworkDiscovery()
    installed_programs = get_installed_programs_linux()
    system_specs = get_system_specs_linux()
    patches = get_patches_linux()
    running_processes = get_running_processes_linux()
    firewall_policies = get_firewall_policies_linux()

    # Save data to json
    filename = save_data_to_json(customer_info ,installed_programs, system_specs, patches, running_processes, firewall_policies, network_discovery)

    # Read the json file and return as a response.
    with open(filename, 'r') as file:
        data = json.load(file)

    return data

@app.get("/collect_and_upload")
def collect_and_upload_data():
    sys.stdout.write("Starting to collect data...\n")
    sys.stdout.write("\n")
    customer_info = Get_Customer_info()
    network_discovery = NetworkDiscovery()
    installed_programs = get_installed_programs_linux()
    system_specs = get_system_specs_linux()
    patches = get_patches_linux()
    running_processes = get_running_processes_linux()
    firewall_policies = get_firewall_policies_linux()
    zipfilename = save_data_to_csv_linux(customer_info ,installed_programs, system_specs, patches, running_processes, firewall_policies, network_discovery)
    #save_data_to_json(customer_info ,installed_programs, system_specs, patches, running_processes, firewall_policies, network_discovery)
    #save_data_to_postgres(customer_info, installed_programs, system_specs, patches, running_processes, firewall_policies)


    #upload_to_cloud(zipfilename)
    sys.stdout.write("Done, all data collected and saved!")
    return {"status": "success", "message": "Data collected and uploaded to postgresql"}

@app.get("/POC")
def POC():
    if manager_POC == "true":
        sys.stdout.write("CYCLOPSE_AGENT: We are in POC mode...\n")
        sys.stdout.write("\n")
        sys.stdout.write("Starting data fetch in\n")
        sys.stdout.write("\n")
        for i in range(10):
            time.sleep(1)
            sys.stdout.write(f"{10 - i} seconds...\n")
            sys.stdout.write("\n")
        my_zip_file = POC_RUN()
        upload_to_manager(my_zip_file)
        return {"status": "success", "message": "CYCLOPSE_AGENT: data uploaded to cyclopse manager"}
    else:
        sys.stdout.write(f"CYCLOPSE_AGENT: ma_POC {manager_POC}\n")
        sys.stdout.write("\n")
        return {"status": "success", "message": "CYCLOPSE_AGENT: We are not in POC mode..."}

def save_data_to_postgres(customer_info ,installed_programs, system_specs, patches, running_processes, firewall_policies):
    sys.stdout.write("Saving data to database...\n")
    sys.stdout.write("\n")
    # Connection parameters - replace with your actual parameters
    conn = psycopg2.connect(
        dbname=db_name,
        user=db_user,
        password=db_pass,
        host=db_host,
        port=db_port
    )

    cur = conn.cursor()
    sys.stdout.write("Connected to database\n")
    sys.stdout.write("\n")
    hostname = socket.gethostname()
    ip_address = socket.gethostbyname(hostname)


    OS = platform.system()
    system_specs["Version"] = platform.release()
    Vendor = platform.platform()
    Installed_On = datetime.fromtimestamp(psutil.boot_time()).strftime("%Y-%m-%d %H:%M:%S")


    # Inserting data into asset table
    cur.execute(
        "INSERT INTO customer_info (Customer_Name, Customer_Phone, Customer_Email) VALUES (%s, %s, %s)",
        (CUSTOMER, CUSTOMER_PHONE, CUSTOMER_EMAIL)
    )
    
    # Inserting data into asset table
    cur.execute(
        "INSERT INTO asset (Asset_Name, Asset_Vendor, Asset_OS, Asset_IP, Asset_Installed_On, Asset_Type, Customer_Name) VALUES (%s, %s, %s, %s, %s, %s, %s)",
        (hostname, Vendor, OS, ip_address, Installed_On, "Server", CUSTOMER)
    )

    sys.stdout.write("customer info done...\n")
    # Inserting data into programs table
    for program in installed_programs:
        cur.execute(
            "INSERT INTO programs (Program_Name, Program_Version, Program_Type, Program_Install_On, Program_Hostname, Program_Size, Program_Vendor, Program_Package_Manager, Customer_Name) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
            (program['Program_Name'], program['Program_Version'], program['Program_Type'], program['Program_Install_On'], hostname, program['Program_Size'], program['Program_Vendor'], program['Program_Package_Manager'], CUSTOMER)
        )
    sys.stdout.write("programs done...\n")

    # Inserting data into firewall table
    for policy in firewall_policies:
        cur.execute(
            "INSERT INTO firewall (Policy_Name, Policy_Type, Policy_Source, Policy_Destination, Policy_Protocol, Policy_Ports, Policy_Customer_Name) VALUES (%s, %s, %s, %s, %s, %s, %s)",
            (policy['Policy_Name'], policy['Policy_Type'], policy['Policy_Source'], policy['Policy_Destination'], policy['Policy_Protocol'], policy['Policy_Ports'], CUSTOMER)
        )
    sys.stdout.write("firewalls done...\n")

    # Inserting data into patches table
    for patch in patches:
        cur.execute(
            "INSERT INTO patches (Patch_Name_ID, Patch_Date, Patch_Package_Manager, Customer_Name) VALUES (%s, %s, %s, %s)",
            (patch['Patch_Name_ID'], patch['Patch_Date'], patch['Patch_Package_Manager'], CUSTOMER)
        )
    sys.stdout.write("pacthes done...\n")

    # Inserting data into processes table
    for process in running_processes:
        sys.stdout.write(f"value: {process}\n")
        sys.stdout.write("\n")
        cur.execute(
            "INSERT INTO processes (Process_Name, Process_Type, Process_Resource_Usage_CPU, Process_Resource_Usage_MEM, Process_Start_Time, Process_PID, Process_Network_Communication_Ports, Customer_Name) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)",
            (process['Process_Name'], process['Process_Type'], process['Process_Resource_Usage']['CPU'], process['Process_Resource_Usage']['MEM'], process['Process_Start_Time'], process['Process_PID'], process['Process_Network_Communication_Ports'], CUSTOMER)
        )
    sys.stdout.write("processes done...\n")


    # # Inserting data into system_specs table
    # Convert the System_Disks list to a JSON formatted string
    system_specs['System_Disks'] = json.dumps(system_specs['System_Disks'])
    try:
        cur.execute(
            "INSERT INTO system_specs (System_OS, System_Version, System_Vendor, System_Hostname, System_IP, System_Type, System_Installed_On, System_Uptime, System_Disks, System_CPU_Total, System_CPU_Usage, System_MEM_Total, System_MEM_Usage, System_Speed_Upload, System_Speed_Download, Customer_Name) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
            (system_specs["System_OS"], system_specs["System_Version"], system_specs["System_Vendor"], system_specs["System_Hostname"], system_specs["System_IP"], system_specs["System_Type"], system_specs["System_Installed_On"], str(system_specs["System_Uptime"]), system_specs["System_Disks"], system_specs["System_CPU_Total"], system_specs["System_CPU_Usage"], system_specs["System_MEM_Total"], system_specs["System_MEM_Usage"], system_specs["System_Speed_Upload"], system_specs["System_Speed_Download"], CUSTOMER)
        )
        sys.stdout.write("System specs saved successfully.\n")
    except Exception as e:
        sys.stdout.write("Failed to save system specs: {}\n".format(e))



    # Commit the transaction
    conn.commit()
    sys.stdout.write("Done inserting data to database\n")
    sys.stdout.write("\n")
    # Close the connection
    cur.close()
    conn.close()
    sys.stdout.write("Closed connection to database\n")
    sys.stdout.write("\n")

@app.get("/upload_to_db")
def collect_and_upload_data():
    sys.stdout.write("Starting to collect data...\n")
    sys.stdout.write("\n")
    customer_info = Get_Customer_info()
    network_discovery = NetworkDiscovery()
    installed_programs = get_installed_programs_linux()
    system_specs = get_system_specs_linux()
    patches = get_patches_linux()
    running_processes = get_running_processes_linux()
    firewall_policies = get_firewall_policies_linux()
    try:
        save_data_to_postgres(customer_info, installed_programs, system_specs, patches, running_processes, firewall_policies)
        return {"status": "success", "message": "Data collected and uploaded to postgresql"}
    except Exception as e:
        sys.stdout.write(f"Failed to save data to database - Error {e}")
        return {"status": "Failure", "message": f"Failed to save data to database - Error {e}"}
    

@app.get("/test/config")
def test():
    db_info = {"name": db_name, "user": db_user, "pass": db_pass, "host": db_host, "port": db_port}
    manager_info = {"hostname": manager_hostname, "ip": manager_ip, "port": manager_port, "username": manager_user, "password": manager_pass, "POC": manager_POC}
    config = {"db_info": db_info, "manager_info": manager_info}
    return {"config": config}
    
@app.get("/test/customer_info")
def test():
    customer_info = Get_Customer_info()
    return {"customer_info": customer_info}
 
@app.get("/test/network_discovery")
def test():
    network_discovery = NetworkDiscovery()
    return {"network_discovery": network_discovery}

@app.get("/test/installed_programs")
def test():
    installed_programs = get_installed_programs_linux()
    return {"installed_programs": installed_programs}

@app.get("/test/system_specs")
def test():
    system_specs = get_system_specs_linux()
    return {"system_specs": system_specs}

@app.get("/test/patches")
def test():
    patches = get_patches_linux()
    return {"patches": patches}

@app.get("/test/running_processes")
def test():
    running_processes = get_running_processes_linux()
    return {"running_processes": running_processes}

@app.get("/test/firewall_policies")
def test():
    firewall_policies = get_firewall_policies_linux()
    return {"firewall_policies": firewall_policies}



