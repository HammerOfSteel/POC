import uvicorn
import argparse

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run FastAPI server")
    parser.add_argument(
        "--log-level",
        default="info",
        choices=["critical", "error", "warning", "info", "debug"],
        help="Set the log level",
    )

    args = parser.parse_args()
    uvicorn.run("agent:app", host="0.0.0.0", port=8000, log_level=args.log_level)
